
INSERT INTO exercisedb.clientdemo (accountid, name, balance, type)
VALUES (1001, "Mohd Ali", 999999, "Saving");

INSERT INTO exercisedb.clientdemo (accountid, name, balance, type)
VALUES (1002, "Luqman Hakim", 299999, "Saving");

INSERT INTO exercisedb.clientdemo (accountid, name, balance, type)
VALUES (1003, "Azizul Awang", 4999999, "Saving");

INSERT INTO exercisedb.clientdemo (accountid, name, balance, type)
VALUES (1004, "Arsene Wenger", 1999999, "Saving");

INSERT INTO exercisedb.clientdemo (accountid, name, balance, type)
VALUES (1005, "Jurgen Klopp", 2999999, "Saving");

INSERT INTO exercisedb.clientdemo (accountid, name, balance, type)
VALUES (1006, "Tan Kai Ji", 899999, "Saving");

INSERT INTO exercisedb.clientdemo (accountid, name, balance, type)
VALUES (1007, "Steven Lim", 29999, "Saving");

INSERT INTO exercisedb.clientdemo (accountid, name, balance, type)
VALUES (1008, "Ram Ramesh", 929999, "Saving");

INSERT INTO exercisedb.clientdemo (accountid, name, balance, type)
VALUES (1009, "Siva Ganesh", 339999, "Saving");
