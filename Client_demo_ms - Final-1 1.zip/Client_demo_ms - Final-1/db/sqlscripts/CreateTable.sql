CREATE TABLE IF NOT EXISTS exercisedb.clientdemo(
  accountid FLOAT NOT NULL PRIMARY KEY,
  name varchar(255),
  balance FLOAT,
  type varchar(255)
);
