import {useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/Header';
import Search from './components/Search';
import InfoCard from './components/InfoCard';
import ClientCard from './components/ClientCard';
import Welcome from './components/Welcome';
import { Container, Row, Col } from 'react-bootstrap';
import {ToastContainer, toast} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const App = () => {
  const [accountid, setAccountid] = useState('');
  const [info, setInfo] = useState([]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    console.log(accountid);
    fetch(`/app/accountid?query=${accountid}`)
      .then((res) => res.json())
      .then((data) => {
        setInfo([{...data, title: accountid }, ...info]);
        toast('Retrieve Account...')
      })
      .catch((err) => {
        console.log(err);
      })
      setAccountid('')
  };

  return (
    <div>
      <Header title="Entity Demo Apps" />
      <Search accountid={accountid} setAccountid={setAccountid} handleSubmit={handleSearchSubmit}/>
      <Container className="mt-4">
          {info.length ?(
            <Row xs={1} md={2} lg={2}>
              <Col className="pb-3">
                    <InfoCard info={info[0]} />
              </Col>
              <Col className="pb-3">
                <ClientCard />
              </Col>
            </Row>
          ):(<Welcome />)
        }
    </Container>
    <ToastContainer position="bottom-right" />
    </div>
  );
}

export default App;
