import React from 'react';
import { Jumbotron, Button } from 'react-bootstrap';

const Welcome = () => (
  <Jumbotron>
    <h1>Entity Demo Apps</h1>
    <p>
      This is simple demo to showcase a legacy monolithic application being containerized to docker format before refactor to microservices.
    </p>
    <p>
      Once being containerized, the application is able to run on Google Kubernetes Engine and on-prem Kubernetes platform.
    </p>
    <p>
      <Button variant="primary" href="https://services.global.ntt/en-us/services-and-products/cloud" target="_blank">
        Learn more
      </Button>
    </p>
  </Jumbotron>
);

export default Welcome;
