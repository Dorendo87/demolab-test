import React, { useEffect, useState } from "react"
import { Card } from 'react-bootstrap';
import client from '../images/client.jpg';

const ClientCard = () => {
  const [tech, setTech] = useState()

  const fetchData = () => {
    fetch(`/pltform/check-platform`)
      .then(response => {
        return response.json()
      })
      .then(data => {
        setTech(data)
      })
    }

  useEffect(() => {
    fetchData()
    }, [])

  return (
    <Card style={{ width: '25rem' }}>
        <Card.Body>
          <Card.Img variant="top" src={client} />
          <Card.Title>Lonpac Insurance Bhd</Card.Title>
          <Card.Text>
            Cloud Demo for Lonpac Technical Team
            <br/>
            Cloud Transformation Journey Presentation
          </Card.Text>
        </Card.Body>
        <Card.Footer class="text-danger">
          <strong>{tech}</strong>
        </Card.Footer>
    </Card>
  );
}

export default ClientCard;
