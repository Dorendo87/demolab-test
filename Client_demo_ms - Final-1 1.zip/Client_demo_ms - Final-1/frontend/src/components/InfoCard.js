import React from 'react';
import { Card, Button } from 'react-bootstrap';
import gold from '../images/gold.jpg';
import silver from '../images/silver.jpg';


const InfoCard = ({info }) => {
  const level = info[1];
  return (
    <Card style={{ width: '25rem' }}>
        <Card.Body>
          {level === "gold" ? <Card.Img variant="top" src={gold} />
            :<Card.Img variant="top" src={silver} />
          }
          <Card.Title>{`Account: ${info.title}`}</Card.Title>
          <Card.Text>
            {`Name: ${info[0][1]}`}
            <br />
            {`Amount:
              ${info[0][2].toLocaleString(undefined, { maximumFractionDigits: 2 })}
            `}
            <br />
            {`Account Type: ${info[0][3]}`}
          </Card.Text>
          <Button variant="primary" href="/">
            Clear
          </Button>
        </Card.Body>
    </Card>
  )
};

export default InfoCard;
