dbConfig = {
    'user' : 'root',
    'password' : "abc123",
    'host' : "db-service",
    'database': "exercisedb"
}
